const { add } = require("./index");

describe("add", () => {
  it("Should return correct sum", () => {
    const result = add(3, 4);

    expect(result).toBe(7);
  });
});
