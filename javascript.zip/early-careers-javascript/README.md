# Boilerplate code for JavaScript project

## Node Installation

Make sure Node is installed on your system https://nodejs.org/en and path variables for Node are set properly.

Verify it by running:

```
node --version
```

It should display the current node version installed on system.

## Package Installation

To install the required dependencies, run the following command:

```
npm install
```

## Running the Project

To execute the main file with code, run:

```
npm run start
```

## Running Tests

To run the tests, use the following command:

```
npm run test
```

Verify you can see the output "All test cases passed!"
