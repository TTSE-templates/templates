const assert = require("assert");

function add(a, b) {
  return a + b;
}

try {
  assert.strictEqual(
    add(3, 5),
    8,
    "Test Case 1 Failed: add(3, 5) should return 8"
  );
  assert.strictEqual(
    add(-2, 5),
    3,
    "Test Case 2 Failed: add(-2, 5) should return 3"
  );
  assert.strictEqual(
    add(0, 0),
    0,
    "Test Case 3 Failed: add(0, 0) should return 0"
  );
  console.log("All test cases passed!");
} catch (error) {
  console.error(error.message);
}
