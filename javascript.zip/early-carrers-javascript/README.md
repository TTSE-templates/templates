# Boilerplate code for JavaScript project

- Make sure Node is installed on your system https://nodejs.org/en and path variables for Node are set properly.

- To execute file with code run:

```
node index.js
```

- Verify you can see the output "All test cases passed!"
