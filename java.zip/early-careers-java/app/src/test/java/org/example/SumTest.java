package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SumTest {

    @Test
    void shouldReturnSum() {
        int sum = Sum.sum(3, 4);
        assertEquals(7, sum);
    }
}
