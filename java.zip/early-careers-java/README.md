# Boilerplate code for Java project

- To execute tests, run the following command:

```
./gradlew clean build test
```

