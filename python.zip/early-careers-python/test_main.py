import main


def test_sum():
    assert main.sum(3, 4) == 7
