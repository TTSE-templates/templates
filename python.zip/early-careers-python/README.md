# Boilerplate code for Python project

- (Optional) Create virtual env

```
python3 -m venv venv
source venv/bin/activate
```

- Install requirements:

```
pip3 install -r requirements.txt
```

- To execute tests, run the following command:

```
pytest
```

